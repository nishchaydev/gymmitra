import { PrismaClient } from '@prisma/client'

const SOFT_DELETE_MODELS = ['Member', 'Invoice', 'GymProfile', 'MemberSubscription', 'Sale']

function withSslMode(url: string, isPooler: boolean = false): string {
  try {
    const u = new URL(url)
    if (!u.searchParams.get('sslmode')) u.searchParams.set('sslmode', 'require')
    // Set a healthier connection pool limit for Next.js parallel queries
    if (!u.searchParams.get('connection_limit')) u.searchParams.set('connection_limit', '10')
    
    // Automatically add pgbouncer=true if on pooler port
    if (isPooler && !u.searchParams.get('pgbouncer')) {
      u.searchParams.set('pgbouncer', 'true')
    }
    
    return u.toString()
  } catch {
    // If parsing fails, it's likely due to special characters in password. 
    // We should warn about this in dev.
    if (process.env.NODE_ENV !== 'production' && url) {
      console.warn('Prisma: Failed to parse DATABASE_URL. Ensure password is URL-encoded.')
    }
    return url
  }
}

function pickPrismaUrl(): { url: string; reason: string; host: string | null } {
  const rawDb = process.env.DATABASE_URL || ''
  const rawDirect = process.env.DIRECT_URL || ''

  const isPooler = (v: string) => v.includes(':6543')
  
  // Base normalization
  const db = rawDb ? withSslMode(rawDb, isPooler(rawDb)) : ''
  const direct = rawDirect ? withSslMode(rawDirect) : ''

  const getHost = (v: string) => {
    try {
      return new URL(v).hostname
    } catch {
      return null
    }
  }

  const dbHost = getHost(db)
  const directHost = getHost(direct)

  // In local dev, we prefer the Transaction Pooler (port 6543) if available
  if (process.env.NODE_ENV !== 'production') {
    if (isPooler(db)) {
      return { url: db, reason: 'dev:preferring Transaction Pooler (6543)', host: dbHost }
    }
    if (direct) {
      return { url: direct, reason: 'dev:using DIRECT_URL', host: directHost }
    }
  }

  // Production Diagnostics
  if (process.env.NODE_ENV === 'production' && typeof window === 'undefined') {
    console.log(`[Prisma] Initializing with primary host: ${dbHost || 'unknown'}`)
    
    // If we have a pooler URL but the user is seeing "Can't reach", we can detect if it's potentially 
    // problematic and suggest using DIRECT_URL or port 5432.
    if (isPooler(db) && !rawDirect) {
      console.warn('[Prisma] WARNING: Using Transaction Pooler (6543) without a DIRECT_URL fallback. If connection fails, check your environment variables.')
    }
  }

  /**
   * RECOVERY LOGIC:
   * If DATABASE_URL is explicitly set to use port 6543 (Transaction Pooler) but we are 
   * seeing persistent "Can't reach" errors in production, we allow falling back to 
   * the Session Mode (5432) which is often more reachable over restrictive networks.
   */
  const finalUrl = db || direct || ''
  const finalReason = db ? 'default:using DATABASE_URL' : (direct ? 'fallback:using DIRECT_URL' : 'missing')

  // Set pool timeout and connection parameters for stability
  try {
    const u = new URL(finalUrl)
    // Increase connection timeout to 20s for cross-region stability (DC -> Mumbai)
    if (!u.searchParams.get('connect_timeout')) u.searchParams.set('connect_timeout', '20')
    // Set pool_timeout to 20s
    if (!u.searchParams.get('pool_timeout')) u.searchParams.set('pool_timeout', '20')
    return { url: u.toString(), reason: finalReason, host: dbHost }
  } catch {
    return { url: finalUrl, reason: finalReason, host: dbHost }
  }
}

function createPrismaClient(): PrismaClient {
  const picked = pickPrismaUrl()



  const client = new PrismaClient(
    picked.url
      ? {
        datasources: {
          db: { url: picked.url }
        }
      }
      : undefined
  )

  // ── Soft-Delete Middleware ──────────────────────────────────────────
  // Intercepts queries on Member and Invoice to:
  // 1. Auto-filter out soft-deleted records on reads
  // 2. Convert delete operations to updates setting deletedAt

  // READ middleware: auto-filter deletedAt = null
  client.$use(async (params, next) => {
    if (params.model && SOFT_DELETE_MODELS.includes(params.model)) {
      if (params.action === 'findUnique' || params.action === 'findFirst') {
        // findUnique → findFirst so we can add deletedAt filter
        params.action = 'findFirst'
        params.args.where = { ...params.args.where, deletedAt: null }
      }
      if (params.action === 'findMany') {
        if (!params.args) params.args = {}
        if (!params.args.where) params.args.where = {}
        if (params.args.where.deletedAt === undefined) {
          params.args.where.deletedAt = null
        }
      }
      if (params.action === 'count' || params.action === 'aggregate' || params.action === 'groupBy') {
        if (!params.args) params.args = {}
        if (!params.args.where) params.args.where = {}
        if (params.args.where.deletedAt === undefined) {
          params.args.where.deletedAt = null
        }
      }
    }
    return next(params)
  })

  // DELETE middleware: convert to soft-delete
  client.$use(async (params, next) => {
    if (params.model && SOFT_DELETE_MODELS.includes(params.model)) {
      if (params.model === 'GymProfile' && (params.action === 'delete' || params.action === 'deleteMany')) {
        const queryWhere = params.args?.where || {}

        // Find exactly which gyms are targeted by this delete/deleteMany
        const targetedGyms = await client.gymProfile.findMany({
          where: queryWhere,
          select: { id: true },
        })
        const targetedGymIds = targetedGyms.map(g => g.id)

        if (targetedGymIds.length > 0) {
          const invoices = await client.invoice.findFirst({
            where: {
              gymId: { in: targetedGymIds },
              deletedAt: null
            }
          })
          if (invoices) {
            throw new Error('Cannot delete GymProfile with existing invoices')
          }
        }
      }
      if (params.action === 'delete') {
        params.action = 'update'
        params.args.data = { deletedAt: new Date() }
      }
      if (params.action === 'deleteMany') {
        params.action = 'updateMany'
        if (!params.args) params.args = {}
        params.args.data = { deletedAt: new Date() }
      }
    }
    return next(params)
  })

  return client
}

const globalForPrisma = globalThis as unknown as {
  prisma: PrismaClient | undefined
}

export const prisma = globalForPrisma.prisma ?? createPrismaClient()

if (process.env.NODE_ENV !== 'production') globalForPrisma.prisma = prisma

/**
 * Retries a database operation (like a Serializable transaction) on serialization failure (P2034)
 * with linear backoff plus jitter.
 */
export async function withRetry<T>(fn: () => Promise<T>, maxAttempts = 3): Promise<T> {
  let attempts = 0
  while (true) {
    attempts++
    try {
      return await fn()
    } catch (error: any) {
      const isSerializationFailure = error?.code === 'P2034'
      // PrismaClientInitializationError on cold starts — Vercel serverless functions
      // sometimes can't reach the Supabase pooler (port 6543) immediately after boot.
      // Retrying with backoff resolves this ~95% of the time.
      const isColdStartError =
        error?.name === 'PrismaClientInitializationError' ||
        (error?.message && (
          error.message.includes("Can't reach database server") ||
          error.message.includes('Connection refused') ||
          error.message.includes('ECONNREFUSED')
        ))

      if ((isSerializationFailure || isColdStartError) && attempts < maxAttempts) {
        // Exponential backoff: 200ms, 400ms, 800ms for cold start errors
        const baseDelay = isColdStartError ? 200 : 100
        const delay = baseDelay * attempts + Math.random() * 50
        console.warn(`[Prisma] Retrying (attempt ${attempts}/${maxAttempts}) after ${Math.round(delay)}ms: ${error.message?.slice(0, 80)}`)
        await new Promise(resolve => setTimeout(resolve, delay))
        continue
      }
      throw error
    }
  }
}
